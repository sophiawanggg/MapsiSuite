Code from Designer to python
cd C:\Users\Astrid\Desktop\SophiaSoftware\MapsiSuite_v4
pyuic5 Mapsi_Suite_Sophia.ui -o Mapsi_Suite_Final_Sophia.py -x 



